# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 19:46:27 2021

@author: oadiguzel
"""

def sum(x,y):
    return x+y

def average(x,y):
    return (x+y)/2

def power(x,y):
    return x**y