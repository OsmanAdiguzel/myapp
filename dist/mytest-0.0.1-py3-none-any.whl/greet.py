# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 19:46:13 2021

@author: oadiguzel
"""
def SayHello(name):
    print("Hello ", name)