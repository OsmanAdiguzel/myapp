# -*- coding: utf-8 -*-
"""
Created on Fri Jul  2 19:46:13 2021

@author: oadiguzel
"""
from setuptools import setup
setup(
      name="mytest",
      version="0.0.1",
      description="for test",
      py_modules=["functions","greet"],
      package_dir={"":"mypackage"},
      )